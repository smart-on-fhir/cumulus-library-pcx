CREATE TABLE pcx__llm_document_topic_wide AS
SELECT  DISTINCT
        nlp.note_ref,
        nlp.encounter_ref,
        nlp.subject_ref,
        'pcx__nlp_document_topic_gpt_oss_120b' AS origin,
        CAST(nlp.generated_on AS VARCHAR) AS generated_on,
        CAST(nlp.task_version AS BIGINT) AS task_version,
        nlp.system_fingerprint,
        nlp.result.response.relevance                                AS response_relevance,
        nlp.result.response.confidence                               AS response_confidence,

        nlp.result.diagnosis.relevance                               AS diagnosis_relevance,
        nlp.result.diagnosis.confidence                              AS diagnosis_confidence,

        nlp.result.molecular.relevance                               AS molecular_relevance,
        nlp.result.molecular.confidence                              AS molecular_confidence,

        nlp.result.event.relevance                                   AS event_relevance,
        nlp.result.event.confidence                                  AS event_confidence,

        nlp.result.metastasis.relevance                              AS metastasis_relevance,
        nlp.result.metastasis.confidence                             AS metastasis_confidence,

        nlp.result.surgery.relevance                                 AS surgery_relevance,
        nlp.result.surgery.confidence                                AS surgery_confidence,

        nlp.result.radiation.relevance                               AS radiation_relevance,
        nlp.result.radiation.confidence                              AS radiation_confidence,

        nlp.result.systemic_therapy.relevance                        AS systemic_therapy_relevance,
        nlp.result.systemic_therapy.confidence                       AS systemic_therapy_confidence,

        nlp.result.laboratory.relevance                              AS laboratory_relevance,
        nlp.result.laboratory.confidence                             AS laboratory_confidence,

        nlp.result.survival_timeline.relevance                       AS survival_timeline_relevance,
        nlp.result.survival_timeline.confidence                      AS survival_timeline_confidence,

        nlp.result.registry_eligibility.relevance                    AS registry_eligibility_relevance,
        nlp.result.registry_eligibility.confidence                   AS registry_eligibility_confidence
FROM
        pcx__nlp_document_topic_gpt_oss_120b AS nlp
WHERE
        nlp.result IS NOT NULL
AND     nlp.task_version = 2
